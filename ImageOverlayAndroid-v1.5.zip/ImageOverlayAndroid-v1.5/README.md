# Image Overlay for Android — v1.5

A lightweight native Android app that places a selected image above other apps as a drawing/reference guide.

## v1.5 changes

- Pinch-zoom now resizes the complete image window; the toolbar remains fixed-size and does not scale with the image.
- The toolbar hides after 2 seconds without interaction.
- When the toolbar hides, the image window becomes non-touchable so drawing apps can receive finger and stylus input through the image.
- A small corner grip remains as the only touch target. Double-tap it to restore the toolbar and editing controls.
- In editing mode, drag the image to move the complete overlay; pinch to resize the image window. Drag the `IMG` toolbar area to reposition it too.
- The image opacity slider remains available while the toolbar is visible.
- Preserves the image history, saved opacity, system light/dark styling, and supplied launcher icon.

## How the touch-through mode works

Android 12 and newer restrict touch events passing through application overlay windows. The app uses a non-touchable overlay window with alpha 0.79 while in drawing mode, which is below Android's documented default maximum obscuring opacity of 0.8. The separate corner grip remains touchable so the image can be reactivated. The grip occupies a small area and therefore captures touches in that small area; the rest of the image area passes touches to the drawing app. Some device manufacturers or secure apps may still restrict overlays.

## Build with Code on the Go

1. Extract the ZIP into a new folder.
2. Open the project root containing `settings.gradle.kts`.
3. Sync Gradle.
4. Run `gradle clean`.
5. Run `gradle :app:assembleDebug`.
6. Export/install `app/build/outputs/apk/debug/app-debug.apk`.

## Build configuration

- Android Gradle Plugin: 9.5.0
- Gradle wrapper: 9.6.1
- AGP built-in Kotlin support (no separate Kotlin Android plugin)
- Compile SDK: 36
- Minimum Android: 8.0 (API 26)
- Application version: 1.5

## GitHub repository

Create an empty repository on GitHub, then push this project folder using Git:

```bash
git init -b main
git add .
git commit -m "Initial Image Overlay Android project"
git remote add origin https://github.com/YOUR-USERNAME/Image-Overlay-Android.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username. Do not commit `local.properties`, `.gradle/`, or `build/` outputs; they are excluded by `.gitignore`. For HTTPS pushes, GitHub requires a personal access token instead of your account password when prompted for a password.

## Verification note

The source, project configuration, manifest, and resources were inspected. A full Android APK build and device-level touch-through test must still be run in Code on the Go because this environment does not have the Android SDK/device runtime.

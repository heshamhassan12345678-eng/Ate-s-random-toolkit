plugins {
    // AGP 9.5.0 includes Kotlin support; a separate Kotlin plugin is not needed.
    id("com.android.application") version "9.5.0" apply false
}

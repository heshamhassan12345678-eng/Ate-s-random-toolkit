# No custom shrinking rules are needed. Release minification is disabled by default.

plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.imageoverlay"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.example.imageoverlay"
        minSdk = 26
        targetSdk = 35
        versionCode = 6
        versionName = "1.5"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    // AGP 9 built-in Kotlin uses compileOptions.targetCompatibility as its
    // default JVM target, so no separate Kotlin compiler configuration is needed.
}

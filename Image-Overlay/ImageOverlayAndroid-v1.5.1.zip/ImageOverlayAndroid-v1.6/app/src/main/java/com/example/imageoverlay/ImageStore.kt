package com.example.imageoverlay

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import org.json.JSONArray
import kotlin.math.max
import kotlin.math.min

/** Persists the full image history (newest first) and overlay opacity. */
object ImageStore {
    private const val PREFS = "image_overlay_preferences"
    private const val KEY_RECENTS = "recent_uris"
    private const val KEY_OPACITY = "image_opacity_percent"
    const val KEY_PENDING_URI = "pending_overlay_uri"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun recentUris(context: Context): List<String> {
        val raw = prefs(context).getString(KEY_RECENTS, "[]") ?: "[]"
        return try {
            val json = JSONArray(raw)
            buildList {
                // Keep the full history. The stored order is newest first.
                for (index in 0 until json.length()) {
                    val value = json.optString(index)
                    if (value.isNotBlank() && value !in this) add(value)
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun addRecent(context: Context, uri: Uri) {
        val old = recentUris(context)
        val uriText = uri.toString()
        // Reopening an existing image moves it to the left-most (newest) position.
        val next = listOf(uriText) + old.filterNot { it == uriText }
        prefs(context).edit()
            .putString(KEY_RECENTS, JSONArray(next).toString())
            .apply()
    }

    fun opacityPercent(context: Context): Int =
        prefs(context).getInt(KEY_OPACITY, 100).coerceIn(0, 100)

    fun setOpacityPercent(context: Context, value: Int) {
        prefs(context).edit().putInt(KEY_OPACITY, value.coerceIn(0, 100)).apply()
    }

    fun imageName(context: Context, uri: Uri): String {
        return try {
            context.contentResolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (index >= 0) cursor.getString(index)?.takeIf { it.isNotBlank() } else null
                } else null
            } ?: "Image"
        } catch (_: Exception) {
            "Image"
        }
    }

    /** Decodes a size-limited bitmap to avoid loading full-resolution camera photos into RAM. */
    fun decodeBitmap(context: Context, uri: Uri, maxWidth: Int, maxHeight: Int): Bitmap? {
        val targetWidth = maxWidth.coerceAtLeast(1)
        val targetHeight = maxHeight.coerceAtLeast(1)
        return try {
            if (Build.VERSION.SDK_INT >= 28) {
                val source = ImageDecoder.createSource(context.contentResolver, uri)
                ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                    val sourceWidth = info.size.width.coerceAtLeast(1)
                    val sourceHeight = info.size.height.coerceAtLeast(1)
                    val scale = min(
                        1f,
                        min(targetWidth.toFloat() / sourceWidth, targetHeight.toFloat() / sourceHeight)
                    )
                    decoder.setTargetSize(
                        max(1, (sourceWidth * scale).toInt()),
                        max(1, (sourceHeight * scale).toInt())
                    )
                    decoder.isMutableRequired = false
                }
            } else {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    BitmapFactory.decodeStream(stream, null, bounds)
                }
                if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

                var sample = 1
                while (bounds.outWidth / (sample * 2) > targetWidth ||
                    bounds.outHeight / (sample * 2) > targetHeight
                ) {
                    sample *= 2
                }
                val options = BitmapFactory.Options().apply {
                    inSampleSize = sample
                    inPreferredConfig = Bitmap.Config.ARGB_8888
                }
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    BitmapFactory.decodeStream(stream, null, options)
                }
            }
        } catch (_: Exception) {
            null
        } catch (_: OutOfMemoryError) {
            null
        }
    }
}

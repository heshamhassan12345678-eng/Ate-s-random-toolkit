package com.example.imageoverlay

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val requestImage = 4101
    private val requestOverlayPermission = 4102
    private lateinit var recentContainer: LinearLayout
    private lateinit var recentScroll: HorizontalScrollView
    private val thumbnailExecutor = Executors.newFixedThreadPool(2)
    private var allRecentUris: List<String> = emptyList()
    private var nextRecentIndex = 0
    private var recentRenderGeneration = 0
    private var suppressRecentScrollLoading = false

    companion object {
        private const val PREFS_NAME = "image_overlay_preferences"
        private const val KEY_FIRST_IMAGE_DIALOG_CONFIRMED = "first_image_dialog_confirmed"
    }

    private val isDarkMode: Boolean
        get() = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES

    private val pageColor: Int
        get() = if (isDarkMode) Color.rgb(20, 21, 26) else Color.rgb(247, 247, 250)
    private val surfaceColor: Int
        get() = if (isDarkMode) Color.rgb(39, 41, 49) else Color.WHITE
    private val primaryTextColor: Int
        get() = if (isDarkMode) Color.rgb(244, 245, 248) else Color.rgb(36, 38, 44)
    private val secondaryTextColor: Int
        get() = if (isDarkMode) Color.rgb(174, 177, 187) else Color.rgb(112, 115, 123)
    private val thumbnailColor: Int
        get() = if (isDarkMode) Color.rgb(29, 31, 38) else Color.rgb(235, 236, 240)
    private val accentColor: Int
        get() = if (isDarkMode) Color.rgb(116, 145, 220) else Color.rgb(54, 75, 135)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applySystemBarColors()
        renderHome()
    }

    private fun applySystemBarColors() {
        val light = !isDarkMode
        window.statusBarColor = pageColor
        window.navigationBarColor = pageColor
        if (Build.VERSION.SDK_INT >= 26) {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = if (light) {
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            } else {
                0
            }
        }
        if (Build.VERSION.SDK_INT >= 29) {
            window.isNavigationBarContrastEnforced = false
            window.isStatusBarContrastEnforced = false
        }
    }

    override fun onResume() {
        super.onResume()
        if (::recentContainer.isInitialized) renderRecentImages()

        val pending = getSharedPreferences("image_overlay_preferences", MODE_PRIVATE)
            .getString(ImageStore.KEY_PENDING_URI, null)
        if (!pending.isNullOrBlank()) {
            getSharedPreferences("image_overlay_preferences", MODE_PRIVATE)
                .edit().remove(ImageStore.KEY_PENDING_URI).apply()
            if (Settings.canDrawOverlays(this)) {
                launchOverlay(Uri.parse(pending))
            } else {
                Toast.makeText(this, "Overlay permission was not enabled.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun renderHome() {
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(pageColor)
            // Android 15+ may draw apps edge-to-edge when targeting API 35.
            setOnApplyWindowInsetsListener { view, insets ->
                val topInset: Int
                val bottomInset: Int
                if (Build.VERSION.SDK_INT >= 30) {
                    val bars = insets.getInsets(
                        WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars()
                    )
                    topInset = bars.top
                    bottomInset = bars.bottom
                } else {
                    topInset = insets.systemWindowInsetTop
                    bottomInset = insets.systemWindowInsetBottom
                }
                view.setPadding(view.paddingLeft, topInset, view.paddingRight, bottomInset)
                insets
            }
        }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(34), dp(22), dp(28))
        }
        scroll.addView(page)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val headingColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        headingColumn.addView(label("Image Overlay", 29f, primaryTextColor, true))
        header.addView(headingColumn)

        val addButton = TextView(this).apply {
            text = "+"
            textSize = 34f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = rounded(accentColor, dp(19))
            layoutParams = LinearLayout.LayoutParams(dp(54), dp(54))
            setOnClickListener { chooseImage() }
            contentDescription = "Add image"
        }
        header.addView(addButton)
        page.addView(header)

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), dp(16), dp(15), dp(15))
            background = rounded(surfaceColor, dp(22))
        }
        // Use LTR ordering regardless of device language: newest image on the left.
        recentContainer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        recentScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            isFillViewport = false
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            clipToPadding = false
            addView(recentContainer, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            setOnScrollChangeListener { _, scrollX, _, _, _ ->
                if (!suppressRecentScrollLoading && recentContainer.width > width &&
                    scrollX + width >= recentContainer.width - dp(220)
                ) {
                    appendRecentPage()
                }
            }
        }
        card.addView(recentScroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ))
        page.addView(card, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply {
            topMargin = dp(24)
        })

        val help = label(
            "Tap an image to open it above your current app. Drag to move it and pinch to resize it; the toolbar stays the same size. After 2 seconds, touches pass through the image for drawing. Double-tap the small corner grip to edit or move it again.",
            14f,
            secondaryTextColor,
            false
        ).apply {
            setPadding(dp(3), dp(18), dp(3), 0)
        }
        page.addView(help)

        setContentView(scroll)
        renderRecentImages()
    }

    private fun renderRecentImages() {
        if (!::recentContainer.isInitialized) return
        recentRenderGeneration++
        suppressRecentScrollLoading = true
        recentContainer.removeAllViews()
        allRecentUris = ImageStore.recentUris(this)
        nextRecentIndex = 0
        recentScroll.scrollTo(0, 0)

        if (allRecentUris.isEmpty()) {
            val empty = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(10), dp(28), dp(10), dp(28))
            }
            empty.addView(label("No images yet", 18f, primaryTextColor, true).apply {
                gravity = Gravity.CENTER
            })
            empty.addView(label("Press + to choose your first image", 13f, secondaryTextColor, false).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(7), 0, 0)
            })
            recentContainer.addView(empty, LinearLayout.LayoutParams(dp(260), dp(150)))
            suppressRecentScrollLoading = false
            return
        }

        appendRecentPage()
        suppressRecentScrollLoading = false
    }

    /** Adds history thumbnails in small batches so a large library stays responsive. */
    private fun appendRecentPage() {
        if (!::recentContainer.isInitialized || nextRecentIndex >= allRecentUris.size) return
        val generation = recentRenderGeneration
        val start = nextRecentIndex
        val end = minOf(start + 12, allRecentUris.size)
        nextRecentIndex = end

        for (index in start until end) {
            val value = allRecentUris[index]
            val uri = Uri.parse(value)
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_LTR
                setPadding(dp(4), dp(3), dp(4), dp(3))
                isClickable = true
                isFocusable = true
                setOnClickListener { openImage(uri) }
            }
            val preview = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                background = rounded(thumbnailColor, dp(12))
                clipToOutline = true
                setImageResource(android.R.drawable.ic_menu_report_image)
                tag = value
                contentDescription = "Saved image ${index + 1}"
            }
            item.addView(preview, LinearLayout.LayoutParams(dp(88), dp(92)))
            val name = ImageStore.imageName(this, uri)
            item.addView(label(name, 11f, primaryTextColor, false).apply {
                gravity = Gravity.CENTER
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                setPadding(dp(2), dp(7), dp(2), 0)
            }, LinearLayout.LayoutParams(dp(96), ViewGroup.LayoutParams.WRAP_CONTENT))
            recentContainer.addView(item, LinearLayout.LayoutParams(dp(104), ViewGroup.LayoutParams.WRAP_CONTENT))

            // Decode tiny thumbnails off the UI thread; large source images stay out of the UI path.
            thumbnailExecutor.execute {
                val bitmap = ImageStore.decodeBitmap(this, uri, dp(100), dp(100))
                runOnUiThread {
                    if (bitmap != null && generation == recentRenderGeneration &&
                        !isFinishing && preview.tag == value
                    ) {
                        preview.setImageBitmap(bitmap)
                    } else {
                        bitmap?.recycle()
                    }
                }
            }
        }

        // On wide screens, load enough items to make the horizontal scroll area overflow.
        recentContainer.post {
            if (generation == recentRenderGeneration && nextRecentIndex < allRecentUris.size &&
                recentScroll.width >= recentContainer.width - dp(220)
            ) {
                appendRecentPage()
            }
        }
    }

    override fun onDestroy() {
        recentRenderGeneration++
        thumbnailExecutor.shutdownNow()
        super.onDestroy()
    }

    private fun chooseImage() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        try {
            startActivityForResult(intent, requestImage)
        } catch (_: Exception) {
            Toast.makeText(this, "No file picker is available on this device.", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("The simple Activity result callback keeps this project free of extra dependencies.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestImage && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            val grantedFlags = data.flags and Intent.FLAG_GRANT_READ_URI_PERMISSION
            try {
                contentResolver.takePersistableUriPermission(
                    uri,
                    if (grantedFlags != 0) grantedFlags else Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {
                // Some picker providers issue temporary grants only. The image may still open now.
            }
            ImageStore.addRecent(this, uri)
            renderRecentImages()
            openImage(uri)
        }
    }

    /** Shows a one-time explanation before the first image preview, with an explicit cancel path. */
    private fun openImage(uri: Uri) {
        val prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
        if (prefs.getBoolean(KEY_FIRST_IMAGE_DIALOG_CONFIRMED, false)) {
            launchOverlay(uri)
            return
        }

        AlertDialog.Builder(this)
            .setTitle("Keep your image on screen")
            .setMessage(
                "Image Overlay can keep this picture visible while you use other apps. " +
                    "Android may ask you to allow display over other apps. Press OK to continue, " +
                    "or Cancel to leave the image in your library."
            )
            .setPositiveButton("OK") { _, _ ->
                prefs.edit().putBoolean(KEY_FIRST_IMAGE_DIALOG_CONFIRMED, true).apply()
                launchOverlay(uri)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun launchOverlay(uri: Uri) {
        if (!Settings.canDrawOverlays(this)) {
            getSharedPreferences("image_overlay_preferences", MODE_PRIVATE)
                .edit().putString(ImageStore.KEY_PENDING_URI, uri.toString()).apply()
            Toast.makeText(this, "Allow Image Overlay to display over other apps, then return here.", Toast.LENGTH_LONG).show()
            try {
                startActivityForResult(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")),
                    requestOverlayPermission
                )
            } catch (_: Exception) {
                getSharedPreferences("image_overlay_preferences", MODE_PRIVATE)
                    .edit().remove(ImageStore.KEY_PENDING_URI).apply()
            }
            return
        }

        val serviceIntent = Intent(this, OverlayService::class.java)
            .setAction(OverlayService.ACTION_SHOW)
            .putExtra(OverlayService.EXTRA_IMAGE_URI, uri.toString())
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent)
            else startService(serviceIntent)
            finish()
        } catch (_: Exception) {
            Toast.makeText(this, "Android could not start the image overlay.", Toast.LENGTH_LONG).show()
        }
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            typeface = Typeface.create("sans-serif", if (bold) Typeface.BOLD else Typeface.NORMAL)
        }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}

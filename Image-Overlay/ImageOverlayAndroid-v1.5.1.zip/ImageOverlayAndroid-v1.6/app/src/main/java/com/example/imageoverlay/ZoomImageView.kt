package com.example.imageoverlay

import android.content.Context
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.widget.ImageView

/**
 * Touch surface for the floating image.
 * Pinching resizes the complete image window; one-finger dragging moves it.
 * The toolbar is a sibling view, so it never scales with the image.
 */
class ZoomImageView(context: Context) : ImageView(context) {
    var onMoveOverlay: ((Float, Float) -> Unit)? = null
    var onInteraction: (() -> Unit)? = null
    var onResizeOverlay: ((Float) -> Unit)? = null

    private var lastRawX = 0f
    private var lastRawY = 0f

    private val scaleDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                onInteraction?.invoke()
                onResizeOverlay?.invoke(detector.scaleFactor)
                return true
            }
        }
    )

    init {
        scaleType = ScaleType.FIT_CENTER
        adjustViewBounds = false
        isClickable = true
        setLayerType(LAYER_TYPE_HARDWARE, null)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        onInteraction?.invoke()
        scaleDetector.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastRawX = event.rawX
                lastRawY = event.rawY
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (event.pointerCount == 1 && !scaleDetector.isInProgress) {
                    val dx = event.rawX - lastRawX
                    val dy = event.rawY - lastRawY
                    if (dx != 0f || dy != 0f) onMoveOverlay?.invoke(dx, dy)
                }
                lastRawX = event.rawX
                lastRawY = event.rawY
                return true
            }
            MotionEvent.ACTION_POINTER_DOWN, MotionEvent.ACTION_POINTER_UP -> {
                lastRawX = event.rawX
                lastRawY = event.rawY
                return true
            }
            MotionEvent.ACTION_UP -> {
                performClick()
                return true
            }
            MotionEvent.ACTION_CANCEL -> return true
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}

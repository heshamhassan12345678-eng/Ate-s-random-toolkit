package com.example.imageoverlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.res.Configuration
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import kotlin.math.max
import kotlin.math.min

class OverlayService : Service() {
    companion object {
        const val ACTION_SHOW = "com.example.imageoverlay.action.SHOW"
        const val ACTION_CLOSE = "com.example.imageoverlay.action.CLOSE"
        const val EXTRA_IMAGE_URI = "image_uri"
        private const val CHANNEL_ID = "image_overlay_active"
        private const val NOTIFICATION_ID = 701
        private const val CONTROLS_HIDE_DELAY_MS = 2_000L
        // Android 12+ allows a single not-touchable application overlay to pass touches
        // through when its window alpha is at or below the system's default 0.8 limit.
        private const val PASS_THROUGH_WINDOW_ALPHA = 0.79f
        private const val MAX_IMAGE_SCALE = 5f

        // Slider 0..99 is stretched over 0..79% of real opacity (touch pass-through works).
        // Slider 100 is a real 100%: the window turns fully solid and no longer passes touches.
        private fun imageAlphaFor(percent: Int): Float =
            if (percent >= 100) 1f else percent.coerceIn(0, 99) / 99f

        private fun windowAlphaFor(percent: Int): Float =
            if (percent >= 100) 1f else PASS_THROUGH_WINDOW_ALPHA
    }

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private var activationHandle: View? = null
    private var activationHandleParams: WindowManager.LayoutParams? = null
    private val controlsHandler = Handler(Looper.getMainLooper())
    private var hideControlsTask: Runnable? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CLOSE) {
            stopOverlay()
            return START_NOT_STICKY
        }

        val uriText = intent?.getStringExtra(EXTRA_IMAGE_URI)
        if (uriText.isNullOrBlank()) {
            stopSelf(startId)
            return START_NOT_STICKY
        }

        try {
            if (!Settings.canDrawOverlays(this)) {
                stopSelf(startId)
                return START_NOT_STICKY
            }
            startAsForeground()
            showImage(Uri.parse(uriText))
        } catch (_: Exception) {
            closeOverlay()
            stopForeground(STOP_FOREGROUND_REMOVE)
            Toast.makeText(this, "Could not open this image overlay.", Toast.LENGTH_LONG).show()
            stopSelf(startId)
            return START_NOT_STICKY
        }
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val closeIntent = Intent(this, OverlayService::class.java).setAction(ACTION_CLOSE)
        val closePendingIntent = PendingIntent.getService(
            this,
            702,
            closeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Image preview is active")
            .setContentText("Double-tap the corner grip to edit or move the image.")
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
                    "Close preview",
                    closePendingIntent
                ).build()
            )
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun showImage(uri: Uri) {
        closeOverlay()
        val manager = windowManager ?: return
        if (!Settings.canDrawOverlays(this)) return

        val density = resources.displayMetrics.density
        val darkMode = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        val controlSurface = if (darkMode) Color.argb(224, 27, 29, 36) else Color.argb(232, 246, 247, 250)
        val controlText = if (darkMode) Color.WHITE else Color.rgb(39, 42, 49)
        val closeSurface = if (darkMode) Color.argb(160, 100, 103, 114) else Color.argb(190, 210, 213, 221)
        val sliderColor = if (darkMode) Color.rgb(160, 183, 255) else Color.rgb(65, 91, 158)
        val screenWidth = resources.displayMetrics.widthPixels.coerceAtLeast(1)
        val screenHeight = resources.displayMetrics.heightPixels.coerceAtLeast(1)
        fun dp(value: Int) = (value * density).toInt().coerceAtLeast(1)

        val toolbarWidth = min(dp(270), (screenWidth - dp(28)).coerceAtLeast(dp(180)))
        val maxImageWidth = min(dp(340), (screenWidth - dp(20)).coerceAtLeast(dp(180)))
        val maxImageHeight = min(dp(410), (screenHeight * 0.58f).toInt().coerceAtLeast(dp(180)))
        val bitmap = ImageStore.decodeBitmap(this, uri, maxImageWidth, maxImageHeight)

        var calculatedWidth: Int
        var calculatedHeight: Int
        if (bitmap != null) {
            val ratio = bitmap.width.toFloat() / bitmap.height.coerceAtLeast(1).toFloat()
            calculatedWidth = maxImageWidth
            calculatedHeight = (calculatedWidth / ratio).toInt()
            if (calculatedHeight > maxImageHeight) {
                calculatedHeight = maxImageHeight
                calculatedWidth = (calculatedHeight * ratio).toInt()
            }
        } else {
            calculatedWidth = min(maxImageWidth, dp(280))
            calculatedHeight = min(maxImageHeight, dp(220))
        }

        // The image view is FIT_CENTER, so a slightly wider viewport can keep the
        // fixed-size toolbar within the image window without stretching the picture.
        val baseWidth = max(calculatedWidth, toolbarWidth + dp(12))
            .coerceAtMost((screenWidth - dp(16)).coerceAtLeast(dp(180)))
        val baseHeight = max(calculatedHeight, dp(140))
            .coerceAtMost((screenHeight - dp(80)).coerceAtLeast(dp(180)))

        val image = ZoomImageView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            if (bitmap != null) {
                setImageBitmap(bitmap)
            } else {
                setImageResource(android.R.drawable.ic_menu_report_image)
                Toast.makeText(
                    this@OverlayService,
                    "The image could not be loaded. Check its file access.",
                    Toast.LENGTH_LONG
                ).show()
            }
            alpha = imageAlphaFor(ImageStore.opacityPercent(this@OverlayService))
            contentDescription = "Floating image. Pinch to resize; drag to move."
        }

        val root = FrameLayout(this).apply {
            background = rounded(Color.TRANSPARENT, dp(16).toFloat())
            clipToOutline = true
            elevation = dp(10).toFloat()
        }
        root.addView(
            image,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )

        // The toolbar is a fixed-size child of the image window. Resizing the image
        // window never scales the toolbar itself.
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(5), 0, dp(8), 0)
            background = rounded(controlSurface, dp(13).toFloat())
            elevation = dp(8).toFloat()
        }

        val closeButton = TextView(this).apply {
            text = "×"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(controlText)
            background = rounded(closeSurface, dp(30).toFloat())
            layoutParams = LinearLayout.LayoutParams(dp(32), dp(32))
            contentDescription = "Close image overlay"
            setOnClickListener { stopOverlay() }
        }
        controls.addView(closeButton)

        val title = TextView(this).apply {
            text = "IMG"
            textSize = 10f
            setTextColor(controlText)
            gravity = Gravity.CENTER
            setPadding(dp(5), 0, dp(5), 0)
            layoutParams = LinearLayout.LayoutParams(dp(34), dp(40))
            contentDescription = "Drag here to move the image"
        }
        controls.addView(title)

        val opacityLabel = TextView(this).apply {
            text = "◐"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(controlText)
            layoutParams = LinearLayout.LayoutParams(dp(24), dp(40))
            contentDescription = "Image opacity"
        }
        controls.addView(opacityLabel)

        val opacitySlider = SeekBar(this).apply {
            max = 100
            progress = ImageStore.opacityPercent(this@OverlayService)
            progressTintList = ColorStateList.valueOf(sliderColor)
            thumbTintList = ColorStateList.valueOf(controlText)
            contentDescription = "Adjust image opacity"
            layoutParams = LinearLayout.LayoutParams(0, dp(38), 1f)
        }
        controls.addView(opacitySlider)

        val opacityValue = TextView(this).apply {
            text = "${opacitySlider.progress}%"
            textSize = 10f
            gravity = Gravity.CENTER
            setTextColor(controlText)
            layoutParams = LinearLayout.LayoutParams(dp(34), dp(40))
        }
        controls.addView(opacityValue)

        val controlParams = FrameLayout.LayoutParams(
            toolbarWidth,
            dp(44),
            Gravity.TOP or Gravity.CENTER_HORIZONTAL
        ).apply {
            setMargins(dp(5), dp(5), dp(5), 0)
        }
        root.addView(controls, controlParams)

        val params = WindowManager.LayoutParams(
            baseWidth,
            baseHeight,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
            alpha = windowAlphaFor(ImageStore.opacityPercent(this@OverlayService))
        }

        var currentScale = 1f
        var lastHandleTap = 0L
        var revealControlsAction: (() -> Unit)? = null

        fun clampWindowPosition() {
            val maxX = ((screenWidth - params.width) / 2).coerceAtLeast(0)
            val maxY = ((screenHeight - params.height) / 2).coerceAtLeast(0)
            params.x = params.x.coerceIn(-maxX, maxX)
            params.y = params.y.coerceIn(-maxY, maxY)
        }

        fun updateActivationHandlePosition() {
            val handle = activationHandle ?: return
            val handleParams = activationHandleParams ?: return
            val handleSize = dp(42)
            val rootLeft = (screenWidth - params.width) / 2 + params.x
            val rootTop = (screenHeight - params.height) / 2 + params.y
            handleParams.gravity = Gravity.TOP or Gravity.LEFT
            handleParams.x = (rootLeft + params.width - handleSize + dp(8))
                .coerceIn(0, (screenWidth - handleSize).coerceAtLeast(0))
            handleParams.y = (rootTop - dp(12)).coerceIn(0, (screenHeight - handleSize).coerceAtLeast(0))
            try { manager.updateViewLayout(handle, handleParams) } catch (_: Exception) { }
        }

        fun moveWindow(deltaX: Float, deltaY: Float) {
            params.x += deltaX.toInt()
            params.y += deltaY.toInt()
            clampWindowPosition()
            try { manager.updateViewLayout(root, params) } catch (_: Exception) { }
            updateActivationHandlePosition()
        }

        fun hideActivationHandle() {
            val handle = activationHandle ?: return
            try { manager.removeView(handle) } catch (_: Exception) { }
            activationHandle = null
            activationHandleParams = null
        }

        fun showActivationHandle() {
            if (activationHandle != null) {
                updateActivationHandlePosition()
                return
            }
            val handle = TextView(this).apply {
                text = "↗"
                textSize = 17f
                gravity = Gravity.CENTER
                setTextColor(controlText)
                background = rounded(controlSurface, dp(22).toFloat())
                elevation = dp(12).toFloat()
                contentDescription = "Double-tap this corner grip to edit, move, or resize the image"
                isClickable = true
                isFocusable = false
                setOnTouchListener { _, event ->
                    if (event.actionMasked == MotionEvent.ACTION_UP) {
                        val now = SystemClock.uptimeMillis()
                        if (lastHandleTap != 0L && now - lastHandleTap <= 350L) {
                            lastHandleTap = 0L
                            hideActivationHandle()
                            revealControlsAction?.invoke()
                        } else {
                            lastHandleTap = now
                        }
                    }
                    true
                }
            }
            val handleParams = WindowManager.LayoutParams(
                dp(42), dp(42),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.LEFT
            }
            activationHandle = handle
            activationHandleParams = handleParams
            try {
                manager.addView(handle, handleParams)
                updateActivationHandlePosition()
            } catch (_: Exception) {
                activationHandle = null
                activationHandleParams = null
            }
        }

        fun scheduleControlsHide() {
            hideControlsTask?.let { controlsHandler.removeCallbacks(it) }
            val task = Runnable {
                if (overlayView === root && root.isAttachedToWindow) {
                    controls.visibility = View.GONE
                    // A not-touchable window lets drawing apps receive finger/stylus input.
                    // On Android 12+, keep this one overlay at <= 0.8 opacity for pass-through.
                    if (ImageStore.opacityPercent(this@OverlayService) < 100) {
                        params.flags = params.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    }
                    try { manager.updateViewLayout(root, params) } catch (_: Exception) { }
                    showActivationHandle()
                }
            }
            hideControlsTask = task
            controlsHandler.postDelayed(task, CONTROLS_HIDE_DELAY_MS)
        }

        fun revealControls() {
            params.flags = params.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            try { manager.updateViewLayout(root, params) } catch (_: Exception) { }
            hideActivationHandle()
            controls.visibility = View.VISIBLE
            scheduleControlsHide()
        }
        revealControlsAction = { revealControls() }

        image.onMoveOverlay = { dx, dy -> moveWindow(dx, dy) }
        image.onInteraction = { revealControls() }
        image.onResizeOverlay = { factor ->
            val maxScaleX = (screenWidth * 0.94f / baseWidth).coerceAtLeast(1f)
            val maxScaleY = (screenHeight * 0.86f / baseHeight).coerceAtLeast(1f)
            val maxScale = min(min(maxScaleX, maxScaleY), MAX_IMAGE_SCALE)
            val minScale = ((toolbarWidth + dp(10)).toFloat() / baseWidth).coerceAtMost(1f)
            currentScale = (currentScale * factor).coerceIn(minScale, max(maxScale, minScale))
            params.width = (baseWidth * currentScale).toInt().coerceAtLeast(toolbarWidth + dp(10))
            params.height = (baseHeight * currentScale).toInt().coerceAtLeast(dp(100))
            clampWindowPosition()
            try { manager.updateViewLayout(root, params) } catch (_: Exception) { }
            updateActivationHandlePosition()
        }

        opacitySlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val safeProgress = progress.coerceIn(0, 100)
                image.alpha = imageAlphaFor(safeProgress)
                params.alpha = windowAlphaFor(safeProgress)
                opacityValue.text = "$safeProgress%"
                if (fromUser) {
                    ImageStore.setOpacityPercent(this@OverlayService, safeProgress)
                    try { manager.updateViewLayout(root, params) } catch (_: Exception) { }
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })

        installDragHandle(title, ::moveWindow, ::revealControls)
        opacitySlider.setOnTouchListener { _, _ -> revealControls(); false }
        opacityLabel.setOnTouchListener { _, _ -> revealControls(); false }

        try {
            manager.addView(root, params)
            overlayView = root
            image.post { revealControls() }
        } catch (error: Exception) {
            overlayView = null
            throw error
        }
    }

    private fun installDragHandle(
        view: View,
        move: (Float, Float) -> Unit,
        onInteraction: () -> Unit
    ) {
        var lastX = 0f
        var lastY = 0f
        view.setOnTouchListener { _, event ->
            onInteraction()
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lastX = event.rawX
                    lastY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - lastX
                    val dy = event.rawY - lastY
                    lastX = event.rawX
                    lastY = event.rawY
                    move(dx, dy)
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> true
                else -> true
            }
        }
    }

    private fun stopOverlay() {
        closeOverlay()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun closeOverlay() {
        hideControlsTask?.let { controlsHandler.removeCallbacks(it) }
        hideControlsTask = null
        val manager = windowManager
        activationHandle?.let { handle ->
            try { manager?.removeView(handle) } catch (_: Exception) { }
        }
        activationHandle = null
        activationHandleParams = null
        overlayView?.let { view ->
            try { manager?.removeView(view) } catch (_: Exception) { }
        }
        overlayView = null
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Image overlay",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Shown while an image is floating over other apps."
        }
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(channel)
    }

    private fun rounded(color: Int, radius: Float): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius
        }

    override fun onDestroy() {
        closeOverlay()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
